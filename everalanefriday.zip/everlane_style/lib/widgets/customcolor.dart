import 'dart:ui';

import 'package:flutter/material.dart';

class CustomColor {
  CustomColor();
  static const Color primaryColor = Color(0xFF973d93);
  static final Color iconColor = Colors.black;
  static final Color buttoniconColor = Colors.white;
}