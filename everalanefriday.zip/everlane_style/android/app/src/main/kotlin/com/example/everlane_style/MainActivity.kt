package com.example.everlane_style

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
